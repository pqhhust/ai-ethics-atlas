# AI Ethics Atlas · 5DA06

Course revision and bank AI governance project preparation, reviewed 1 November 2026.

**Website:** https://pqhhust.github.io/ai-ethics-atlas/

- 13 course modules, drawing on four slide decks and eight lecture transcripts.
- 40 written questions, including six supplied course examples, with answer outlines.
- Four mock exams and a self-review rubric. Timings and scoring are practice tools, not official exam rules.
- Original banking scenario reproduced unchanged from the supplied DOCX.
- Reading paths for all five role cards: computer scientist, compliance, ethics, cybersecurity and project management.
- Bank project decisions, release gates, opening statement and 30 Compliance Officer oral drills.
- 102 complete selected legal provisions, annexes or operative rulings, with official source links.
- PDF and Word preparation packs; complete official legal PDFs and a combined compendium.

## Use

Open the website. Notes, confidence ratings and progress remain in the current browser. Export notes to transfer them or keep a backup. No account or backend is required.

To run locally, serve this folder with `python -m http.server 8000`, then open `http://localhost:8000`. Opening `index.html` directly will not load the JSON reader reliably.

## Sources and scope

The Sources page identifies slide pages, broad recording intervals, and corrections. The project is based on *AI Ethics - Group Project.docx* and the course video guidelines. Proposed controls are recommendations, not claims that the bank implemented or tested them.

Legal text is sourced from official EU publications and French legal sources; each entry includes its original source URL and version. The legal appendix reproduces complete selected provisions. The compendium contains complete official instruments and judgments. French Labour Code articles are included in the appendix and linked to the official government labour-code service.

The consolidated AI Act is dated 27 July 2026. Legal application dates are explained by provision; a transition for some high-risk requirements is not presented as a delay of every AI Act duty. Lecture statements are distinguished from current legal wording.

The transcript-derived synthesis excludes raw classroom conversations and recordings. Private account details, API keys and group lists are not included.

Course slides remain attributed to their original authors. Legal texts and third-party course material retain their applicable rights; no blanket licence is asserted over them.

## Navigation and updates

The site groups exam revision, the five project-preparation steps, and reference material. Role links accept common role-name aliases; unrecognised role links return to the chooser. Published JavaScript, CSS and data use content-hashed filenames so a new page cannot reuse an older incompatible asset. The original scenario is unchanged.

## Rehearsal dialogue

The Rehearsal dialogue page publishes section C of the user-supplied Phase 3 package, verbatim: seven timed sections, 24 speaker turns, speaking cues and delivery notes. It includes speaker highlighting, a seven-minute start/pause/reset timer, section navigation and PDF/Word/text downloads. The supplied script is separate from the original course scenario and the sourced legal reader.
